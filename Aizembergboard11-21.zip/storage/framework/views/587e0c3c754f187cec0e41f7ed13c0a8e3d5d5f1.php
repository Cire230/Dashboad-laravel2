<?php $__env->startSection('content'); ?>
<section>

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style="width: 25%;margin-left: 60px;">CoolAdminr</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

</section>

<section>

    <div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark" style="width: 280px; height: 100%; margin-top: 70px;">
        <ul class="nav nav-pills flex-column mb-auto">
            <li class="mb-1">
                <button class="nav-link text-white" data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false" style="color:white !important;">
                    Dashboard
                </button>
                <div class="collapse" id="home-collapse">
                <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                    <li><a href="#" class="nav-link text-white" style="color:white !important; margin-left: 30px;">Dashboard 1</a></li>
                    <li><a href="#" class="nav-link text-white" style="color:white !important; margin-left: 30px;">Dashboard 2</a></li>
                    <li><a href="#" class="nav-link text-white" style="color:white !important; margin-left: 30px;">Dashboard 3</a></li>
                    <li><a href="#" class="nav-link text-white" style="color:white !important; margin-left: 30px;">Dashboard 4</a></li>
                </ul>
                </div>
            </li>
        </li>
        <li>
            <a href="#" class="nav-link text-white">
            <svg class="bi me-2" width="16" height="16"><use xlink:href="#table"></use></svg>
            Charts
            </a>
        </li>
        <li>
            <a href="#" class="nav-link text-white">
            <svg class="bi me-2" width="16" height="16"><use xlink:href="#grid"></use></svg>
            Tables
            </a>
        </li>
        <li>
            <a href="#" class="nav-link text-white">
            <svg class="bi me-2" width="16" height="16"><use xlink:href="#people-circle"></use></svg>
            Forms
            </a>
        </li>
        <li>
            <a href="#" class="nav-link text-white">
            <svg class="bi me-2" width="16" height="16"><use xlink:href="#people-circle"></use></svg>
            Calendar
            </a>
        </li>
        <li>
            <a href="#" class="nav-link text-white">
            <svg class="bi me-2" width="16" height="16"><use xlink:href="#people-circle"></use></svg>
            Mpas
            </a>
        </li>
        <li>
            <a href="#" class="nav-link text-white">
            <svg class="bi me-2" width="16" height="16"><use xlink:href="#people-circle"></use></svg>
            Pages
            </a>
        </li>
        <li>
            <a href="#" class="nav-link text-white">
            <svg class="bi me-2" width="16" height="16"><use xlink:href="#people-circle"></use></svg>
            UI elements
            </a>
        </li>
        </ul>
        <hr>
    </div>

</section>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Labo\Laravel\Aizembergboard\resources\views/welcome.blade.php ENDPATH**/ ?>